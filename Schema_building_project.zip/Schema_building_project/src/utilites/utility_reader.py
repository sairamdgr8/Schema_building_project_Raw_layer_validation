from pyspark.sql import SparkSession
from pyspark.sql import DataFrame



class Utiltiy_reader:
    def Spark_session(self):
        """
        :return:
        Spark  Session Builder
        """
        spark = SparkSession.builder.appName("Schema_building_project").getOrCreate()
        return spark







