from utilites import json_read_schema, utility_reader
import logging
from pyspark.sql import DataFrame

import os

logging.info(os.curdir)
logging.info(os.path)
logging.info(os.walk)

class Src_main:
    if __name__ == "__main__":

        def dataframe_read(self: DataFrame) -> DataFrame:
            """
            :return:
             this method is to determine the dataframe reading functionality
            """
            df = aa.Spark_session().read.option("Header", True).option("inferSchema", True).csv(a.meta_schema_read()["source_input_path"])
            return(df)


logging.info("src main class")
# reading json_read_schema class
a = json_read_schema.Json_read_schema()
logging.info(a.meta_schema_read())
logging.info(a.meta_schema_read()["target_location_path"])

# reading utility class
aa = utility_reader.Utiltiy_reader()

logging.info("************************** local json ******************* ")

logging.info(a.meta_schema_read()['studentsMetaSchema'])

json_column_name_list = []
json_dtype_list = []
for col in a.meta_schema_read()['studentsMetaSchema']:
    json_column_name_list.append(col['metaName']), json_dtype_list.append(col['metaDatatype'])

#calling main function
b = Src_main()

logging.info("************************** Spark  ***********************")
spark_column_name_list = []
spark_column_dtype_list = []
for col in b.dataframe_read().dtypes:
    logging.info(col[0]+" , "+col[1])
    spark_column_name_list.append(col[0]), spark_column_dtype_list.append(col[1])
logging.info(spark_column_name_list)
logging.info(spark_column_dtype_list)

logging.info(b.dataframe_read().printSchema())
logging.info(json_column_name_list)
logging.info(spark_column_name_list)

logging.info(json_column_name_list == spark_column_name_list)

if (len(json_column_name_list) == len(spark_column_name_list)) & (json_column_name_list == spark_column_name_list) is True:
    print("***************** Writing to target location *********************")
    b.dataframe_read().write.mode("overwrite").csv(a.meta_schema_read()["target_location_path"])
else:
    print("*************Source data Schema not matching with the Metaschema******")
